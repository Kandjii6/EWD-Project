<?php 
session_start();;

// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['Learner ID'])) {
	$user_id = $_GET['Leaner ID'];

	// write delete query
	$sql = "DELETE FROM `assesments` WHERE `Leaner ID`='$LID'";

	// Execute the query

	$result = $db->query($sql);

	if ($result == TRUE) {
		echo "Record deleted successfully.";
	}else{
		echo "Error:" . $sql . "<br>" . $db->error;
	}
}

?>