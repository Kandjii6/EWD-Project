 <?php 
include('Session.php');
// if the form's update button is clicked, we need to process the form
	if (isset($_POST['update'])) {
		$LID = $_POST['LID'];
		$Subject = $_POST['Subject'];
		$testmark = $_POST['testmark'];
		$test = $_POST['test'];
		$AssignmentM = $_POST['AssignmentM'];
		$Assignement = $_POST['Assignement'];
		$Average = $_POST['Average'];

		// write the update query
        $sql = "UPDATE `assesments` SET `Leaner ID`= $LID `Subject`= $Subject `Test Mark`= $testmark ` Test %`=$test  `Assignement Mark`=$AssignmentM `Assignment %`= $Assignement `Average Total`= $Average WHERE =`Leaner ID`='$LID'";
		// execute the query
		$result = $db->query($sql);

		if ($result == TRUE) {
			echo "Record updated successfully.";
		}else{
			echo "Error:" . $sql . "<br>" . $db->error;
		}
	}


// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['Leaner ID'])) {
	$LID = $_GET['Leaner ID'];

	// write SQL to get user data
	$sql = "SELECT * FROM `assesments`  WHERE `Leaner ID`='$LID'";

	//Execute the sql
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		
		while ($row = $result->fetch_assoc()) {
			$LID = $row['LID '];
			$Subject = $row['Subject'];
			$testmark = $row['testmark'];
			$test = $row['test'];
			$AssignmentM = $row['AssignmentM'];
			$Assignement = $row['Assignement'];
			$Average = $row['Average'];
		}

	?>
		<h2>Assessment Update Form</h2>
		<form action="" method="post">
		  <fieldset>
		    <legend>Marks:</legend>
		    Leaner ID:<br>
		    <input type="text" name="LID" value="<?php echo $LID; ?>">
		    <input type="hidden" name="Leaner ID" value="<?php echo $id; ?>">
		    <br>
		    Subject:<br>
		    <input type="text" name="Subject" value="<?php echo $Subject; ?>">
		    <br>
		    Test marks:<br>
		    <input type="number" name="testmark" value="<?php echo $testmarks; ?>">
		    <br>
		    Test %:<br>
		    <input type="number" name="test" value="<?php echo $test; ?>">
		    <br>
			 Assignment Mark:<br>
		    <input type="number" name="AssignmentM" value="<?php echo $AssignmentM; ?>">
		    <br>
			 Assignment%:<br>
		    <input type="number" name="Assignement" value="<?php echo $Assignement; ?>">
		    <br>
			 Average Total %:<br>
		    <input type="number" name="Average" value="<?php echo $Average; ?>">
		    <br>
		    
		    <input type="submit" value="Update" name="update">
		  </fieldset>
		</form>

		</body>
		</html>




	<?php
	} else{
		// If the 'id' value is not valid, redirect the user back to view.php page
		header('Location: Home.php');
	}

}
?>