<?php
session_start();
if(isset($_POST['save']))
{
    extract($_POST);
    include 'Database.php';
    $sql=mysqli_query($conn,"SELECT * FROM users where Email='$email' and Password='md5($pass)'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        $_SESSION["Email"]=$row['Email'];
        $_SESSION["First_Name"]=$row['First_Name'];
        $_SESSION["Last_Name"]=$row['Last_Name']; 
        header("Location: Home.php"); 
    }
    else
    {
        echo "Invalid Email ID/Password";
    }
}
?>