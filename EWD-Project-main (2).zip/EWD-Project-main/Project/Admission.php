<!doctype html>
<html>
<head>
<title>Admission</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="School.css" rel="stylesheet" type="text/css">
</head>

<body>
<header> <img src="https://wallpapercave.com/wp/wp5016555.jpg" class="profile-img">
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="Admission.php">Adimssion</a></li>
      <li><a href="Registration.php">Registration</a></li>
      <li><a href="Staff.php">Staff</a></li>
      <li><a href="Announcement.php">Announcement</a></li>
      <li><a href="Contact.php">Contact Us</a></li>
	  <li><a href="Sign up.php">Sign Up</a></li>
	  <li><a href="log in.php">Log In</a></li>
    </ul>
  </nav>
</header>
<main>
  <section id="Education">
    <div class="section-inner"> <img src="https://www.niche.com/blog/wp-content/uploads/2019/06/grad-school-applications-1200-1200x794.jpg" class="profile-img">
	
      <h2>Admission</h2>
	 <center>
     
 <form method="post">
  <fieldset><legend>Application Form</legend>
 
<p>
<label for="Student ID">Student ID:</label>
<input type="text" name="Stid" placeholder="Enter enter id "/>
<p></p>
<label for="stFirstname">First name: </label>
<input type="text" name="name"/>
</p><p>
<label for="stLastName">Last Name: </label>
<input type="text" name="lname"/>
</p><p>
<label for="stEmail">Email: </label>
<input type="email" name="email" placeholder="example@gmail.com"/>
</p><p>
 
 <label for="number">Cellphone Number: </label>
<input type="text" name="number" placeholder= />
</p><p>
  <label for="Department">Department: </label>
<input type="text" name="department"/>
</p><p>
<label for="Course">Course: </label>
<input type="text" name="course "/>
</p><p>
<input type="submit" value="submit"/>
</fieldset>
</form>
 </form>
  </center> 
  </section>
</main>
<footer> @ Copyright C Heuva JSS, 2021 </footer>
</body>
</html>

<?php
$conn = mysqli_connect('localhost','root','');
    if(!$conn){
        die('Could not Connect My Sql:' .mysql_error());
    }
  
  $StudentID = $_POST['Stid'];
  $FirstName = $_POST['name'];
  $LastName = $_POST['lname'];
  $Number= $_POST['number'];
  $Email = $_POST['email'];
  $Number =$_POST['number'];
  $Department = $_POST['department'];
  $Course = S_POST['course'];
  
  $sql= "INSERT INTO adimssion(First Name, Last Name, Email, Department, Course) VALUES ('$StudentID','$FirstName', '$LastName', '$Email', '$Number' , '$Department', '$Course')";

if(!mysqli_query($conn,$sql))
{
	echo ' not inserted';
}
else
{
echo 'inserted';
}
header("refresh:2; url=admission.php");

?>


