<!doctype html>
<html>
<head>
<title>Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="School.css" rel="stylesheet" type="text/css">
<style>
* {
    box-sizing: border-box;
}
.column {
    float: left;
    width: 33.33%;
    padding: 5px;
}
.row::after {
    content: "";
    clear: both;
    display: table;
}
</style>
</head>

<body>
<header> <img src="https://wallpapercave.com/wp/wp5016555.jpg" class="profile-img">
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="Admission.php">Adimssion</a></li>
      <li><a href="Registration.php">Registration</a></li>
      <li><a href="Staff.php">Staff</a></li>
      <li><a href="Announcement.php">Announcement</a></li>
      <li><a href="Contact.php">Contact Us</a></li>
	  <li><a href="Sign up.php">Sign Up</a></li>
	  <li><a href="log in.php">Log In</a></li>
    </ul>
  </nav>
</header>
<main>
  <section id="Home">
    <div class="section-inner"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhVn9krw4KyaZv0-OPflrIY4K4PN4jKaGN3A&usqp=CAU" class="profile-img">
      <h1>Welcome to C Heuva Junior Secondary School </h1>
      <p></p>
      <h2></h2>
      <h3></h3>
      <p></p>
    </div>
    <div class="row">
      <div class="column"> <img src="https://www.unam.edu.na/sites/default/files/galleries/1_0.jpg" class="profile-img"style="width:50%"> </div>
      <div class="column"> <img src="https://media.istockphoto.com/photos/education-high-school-building-entrance-copyspace-and-sky-picture-id173761967?k=6&m=173761967&s=612x612&w=0&h=6j8E8UfynbOi5jKSEkoR-jkRsKzsW848sr8vI08_Ync=" class="profile-img" style="width:50%"> </div>
      <div class="column"> <img src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Larkmead_School%2C_Abingdon%2C_Oxfordshire.png" class="profile-img" style="width:50%"> </div>
    </div>
  </section>
</main>
<footer> @ Copyright C Heuva JSS, 2021 </footer>
</body>
</html>
