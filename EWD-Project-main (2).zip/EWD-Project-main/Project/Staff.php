<!doctype html>
<html>
<head>
<title>Staff</title>
<link href="School.css" rel="stylesheet" type="text/css">
</head>

<body>
<header> <img src="https://wallpapercave.com/wp/wp5016555.jpg" class="profile-img">
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="Admission.php">Adimssion</a></li>
      <li><a href="Registration.php">Registration</a></li>
      <li><a href="Staff.php">Staff</a></li>
      <li><a href="Announcement.php">Announcement</a></li>
      <li><a href="Contact.php">Contact Us</a></li>
	  <li><a href="Sign up.php">Sign Up</a></li>
	  <li><a href="log in.php">Log In</a></li>
    </ul>
  </nav>
</header>
<main>
  <section id="Staff">
    <div class="section-inner"> <img src="https://schoolsweek.co.uk/wp-content/uploads/2020/01/group-analysis-of-digital-data-picture-id954307646-670x352.jpg" class="profile-img">
      <h2>Staff</h2>
      <p> For more enquiries contact us at: <a href="Jeanne Strauss: jstrauss62@gmail.com">Email</a> or give us a call at: +264 81 41 999 71 </p>
    </div>
  </section>
</main>
<footer> @ Copyright C Heuva JSS, 2021 </footer>
</body>
</html>
