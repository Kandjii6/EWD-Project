<!doctype html>
<html>
<head>
<title>Registration</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="School.css" rel="stylesheet" type="text/css">
</head>

<body>
<header> <img src="https://wallpapercave.com/wp/wp5016555.jpg" class="profile-img">
  <nav>
    <ul>
      <li><a href="Home.php">Home</a></li>
      <li><a href="Admission.php">Adimssion</a></li>
      <li><a href="Registration.php">Registration</a></li>
      <li><a href="Staff.php">Staff</a></li>
      <li><a href="Announcement.php">Announcement</a></li>
      <li><a href="Contact.php">Contact Us</a></li>
	  <li><a href="Sign up.php">Sign Up</a></li>
	  <li><a href="log in.php">Log In</a></li>
    </ul>
  </nav>
</header>
<main>
  <section id="Registrations">
    <div class="section-inner"> <img src="https://assets.entrepreneur.com/content/3x2/2000/20190509074950-Apply-Now-Startup-School-Online-Course-Bigstock-4000pxW-X-2670pxH-copy.jpeg?width=700&crop=2:1" class="profile-img">
      
	  <h2>Registration</h2>
	  <center>
     
	 <form method="post">
  <fieldset><legend>Registration</legend>
  <h3> Register here</h3>
<p>
<label for="stID"> Student ID:</label>
<input type="text" name="stID" placeholder=""/>
<p></p>
<label for="stFirstname">Firstname: </label>
<input type="text" name="name"/>
</p><p>
<label for="stLastName">Last Name: </label>
<input type="text" name="surname"/>
</p><p>
<label for="stEmail">Email: </label>
<input type="email" name="email" placeholder="example@gmail.com"/>
</p><p>
  <label for="stGender">Gender:Male or Female</label><br>
  <input type="radio" name="Male" value="Male"/>
  <input type="radio" name="female" value="Female"/>
   
  </p><p> 
<label for="DOB">Date Of Birth:</label>
<input type="date" id="DOB" name="birth">
</p><p>
<label for="stAddress">Address: </label>
<input type="text" name="address"/>
</p><p>
<label for="course">Choose a course:</label>
  <select name="course" id="course">
    <option value="Science">Science</option>
    <option value="Commerce">Commerce</option>
    <option value="Social Science">Social Science</option>
    <option value="Management Science">Management Science</option>
  </select>
</p>
<input type="submit" value="submit"/>
</fieldset>
</form>
 </form>
  </center>
    </div>
  </section>
</main>
<footer> @ Copyright C Heuva JSS, 2021 </footer>
</body>
</html>
<?php
$conn=mysqli_connect($url,$username,$password,"JSS School");
    if(!$conn){
        die('Could not Connect My Sql:' .mysql_error());
    }
  
  $StudentID = $_POST['Stid'];
  $FirstName = $_POST['name'];
  $LastName = $_POST['lname'];
  $Number= $_POST['number'];
  $Email = $_POST['email'];
  $Number =$_POST['number'];
  $Department = $_POST['department'];
  $Course = S_POST['course'];
  
  $sql= "INSERT INTO adimssion(First Name, Last Name, Email, Department, Course) VALUES ('$StudentID','$FirstName', '$LastName', '$Email', '$Number' , '$Department', '$Course')";

if(!mysqli_query($conn,$sql))
{
	echo ' not inserted';
}
else
{
echo 'inserted';
}
header("refresh:2; url=admission.php");

?>
